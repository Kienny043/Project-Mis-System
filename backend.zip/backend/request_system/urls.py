from django.urls import path
from .views import (
    RequestListCreateView,
    RequestRetrieveUpdateView,
)

urlpatterns = [
    path("", RequestListCreateView.as_view(), name="request-list"),
    path("<int:pk>/", RequestRetrieveUpdateView.as_view(), name="request-detail"),
]
