from django.contrib import admin
from .models import StaffProfile

admin.site.register(StaffProfile)
